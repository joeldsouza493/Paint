Paint Application.

Joel D'souza
111503017

Paint is a free drawing program. It has a simple and easy-to-use interface. It provides a blank canvas on the right side of the vertical line and a variety of drawing tools on the left to help you be creative. Paint has 255 * 255 * 255 color combinations and you can choose any using Palette provided in the tools section. Paint can also save the canvas area in png format using the Save Tool.

How to select icon ? 
To select a tool, click on the icon. Border on icon indicates that it is selected. to deselect, click anywhere on the left of the vertical line. To Select any icon, you must first deselect the current tool. You can also use right click to deselect a tool.

Tools and Uses:

PENCIL : Used to make free hand drawings.

LINE : Used to make a line between two points.

RECTANGLE : Used to make rectangle using two opposite points.

POLYGON : Used to make simultaneous lines. Right click ends the process.

FILL COLOR : Fills color throughout pixel by pixel unless borders are encountered.

BRUSH : Used to brush current color on the canvas.

PICK COLOR : Used to make the color of the selected pixel as Palette's Color.

SPRAY : Used to spray current color on the Canvas.

ERASER : Used to erase drawings on the canvas.

PALETTE : Pops up a new window. Select any color. There is custom color palette which allows to select any color out of 255 * 255 * 255 rgb combinations.

SAVE : Saves image in default folder with default name in .png format.

UNDO : Reverses any operation done on the canvas.

REDO : Counters the action of Undo.

The Pixel Data are stored in two Stacks, one for Undo and another for Redo.

======================================================== ENJOY ==================================================================

